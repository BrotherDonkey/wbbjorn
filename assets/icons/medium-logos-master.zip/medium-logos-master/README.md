# Medium Logos

This repo contains versions of our logo and wordmark in popular formats. Feel free to
use these anywhere on the web with a few simple guidelines: Do not modify or alter the
Medium logo or use it in a confusing way, including suggesting sponsorship or endorsement
by Medium, or in a way that confuses Medium with another brand.

[For full brand guidelines read this.](https://medium.com/policy/logos-and-brand-guidelines-f1a01a733592)

If you have any questions, email us at yourfriends@medium.com.

Thanks
